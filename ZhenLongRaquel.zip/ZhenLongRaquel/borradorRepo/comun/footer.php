<footer>
    <div id="divFooter">
        <div>
            <h4>DIRECCIÓN</h4>
            <br />
            <p>Rúa do Horreo 20 - 15820<br />Santiago de Compostela</p>
        </div>
        <div>
            <h4>HORARIO</h4>
            <br />
            <p>Lunes a viernes 13:00 a 16:15 <br />y de 20:00 a 24:45</p>
        </div>
        <div>
            <h4>SÍGUENOS</h4>
            <br />
            <p>Nuestras redes sociales</p>
            <br />
            <div id="divLogos">
                <a href="https://www.instagram.com" target="_blank">
                    <img
                        src="img/logoInstagram.png"
                        alt="Instagram"
                        id="logoInstagram" />
                </a>

                <a href="https://www.facebook.com" target="_blank">
                    <img
                        src="img/logoFacebook.png"
                        alt="Facebook"
                        id="logoFacebook" />
                </a>
            </div>
        </div>
    </div>
    <div id="parrafoFooter">
        <p>
            2025 Restaurante Zhèn Lông Santiago de Compostela - Todos los derechos
            reservados - Política de Privacidad - Politica de cookies -
        </p>
        <a href="../contacto.php"> Contacto</a>
    </div>
</footer>